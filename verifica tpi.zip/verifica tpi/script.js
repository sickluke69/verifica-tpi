// Funzione per caricare i dati dal file JSON
async function loadData() {
    try {
        const response = await fetch('file json.json');
        if (!response.ok) throw new Error('Network response was not ok');
        const jsonData = await response.json();
        displayAmbientazioni(jsonData);
    } catch (error) {
        console.error('Errore nel caricamento dei dati:', error);
    }
}

// Funzione per visualizzare le ambientazioni
function displayAmbientazioni(data) {
    const container = document.getElementById('ambienti-container');
    const ambienti = data["ITI GALILEO FERRARIS"];

    // Ambienti primo piano
    const primoPiano = ambienti["ambienti primo piano"];
    const primoPianoDiv = document.createElement('div');
    primoPianoDiv.classList.add('environment');
    primoPianoDiv.innerHTML = `<h3>${primoPiano.tipo} (Primo Piano)</h3>
                                <p>Capienza: ${primoPiano.capienza}</p>
                                <p>Attrezzature: ${primoPiano.attrezzature.join(', ')}</p>`;
    container.appendChild(primoPianoDiv);

    // Ambienti secondo piano
    const secondoPiano = ambienti["ambienti secondo piano"];
    const secondoPianoDiv = document.createElement('div');
    secondoPianoDiv.classList.add('environment');
    secondoPianoDiv.innerHTML = `<h3>${secondoPiano.tipo} (Secondo Piano)</h3>
                                 <p>Capienza: ${secondoPiano.capienza}</p>
                                 <p>Attrezzature: ${secondoPiano.attrezzature.join(', ')}</p>`;
    container.appendChild(secondoPianoDiv);

    // Ambienti in centrale
    const centrale = ambienti["ambienti in centrale"];
    const centraleDiv = document.createElement('div');
    centraleDiv.classList.add('environment');
    centraleDiv.innerHTML = `<h3>${centrale.tipo1} (Centrale)</h3>
                             <p>Capienza: ${centrale.capienza1}</p>
                             <p>Attrezzature: ${centrale.attrezzature1.join(', ')}</p>`;
    centraleDiv.innerHTML += `<h3>${centrale.tipo2} (Centrale)</h3>
                              <p>Capienza: ${centrale.capienza2}</p>
                              <p>Attrezzature: ${centrale.attrezzature2.join(', ')}</p>`;
    container.appendChild(centraleDiv);
}

// Chiamata per caricare i dati al caricamento della pagina
loadData();
